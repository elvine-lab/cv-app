import React, { useState } from "react";
import jsPDF from "jspdf";
import "../styles/CVBuild.css";

export default function CVBuilder() {
  const [formData, setFormData] = useState({
    name: "",
    city: "",
    phone: "",
    email: "",
    linkedin: "",
    website: "",
    about: "",
    skills: "",
    experience: [
      {
        jobTitle: "",
        company: "",
        location: "",
        from: "",
        to: "",
      },
    ],
    education: [
      {
        diploma: "",
        university: "",
        location: "",
        from: "",
        to: "",
      },
    ],
    certification: "",
    projects: "",
    language: "",
    references: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleExperienceChange = (index, field, value) => {
    const updated = [...formData.experience];
    updated[index][field] = value;
    setFormData((prev) => ({ ...prev, experience: updated }));
  };

  const handleEducationChange = (index, field, value) => {
    const updated = [...formData.education];
    updated[index][field] = value;
    setFormData((prev) => ({ ...prev, education: updated }));
  };

  const addExperience = () => {
    setFormData((prev) => ({
      ...prev,
      experience: [
        ...prev.experience,
        { jobTitle: "", company: "", location: "", from: "", to: "" },
      ],
    }));
  };

  const addEducation = () => {
    setFormData((prev) => ({
      ...prev,
      education: [
        ...prev.education,
        { diploma: "", university: "", location: "", from: "", to: "" },
      ],
    }));
  };

  const handleSubmit = () => setIsSubmitted(true);
  const handleEdit = () => setIsSubmitted(false);

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.html(document.querySelector(".cv-preview"), {
      callback: function (pdf) {
        pdf.save("cv.pdf");
      },
      x: 10,
      y: 10,
    });
  };

  return (
    <div className="cv-container">
      {!isSubmitted ? (
        <div className="cv-form">
          <h2>CV Builder</h2>
          <h3>General Information</h3>
          <input name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required />
          <input name="city" placeholder="City, County" value={formData.city} onChange={handleChange} required />
          <input name="phone" type="tel" placeholder="Phone Number" value={formData.phone} onChange={handleChange} required />
          <input name="email" type="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
          <input name="linkedin" placeholder="LinkedIn" value={formData.linkedin} onChange={handleChange} />
          <input name="website" placeholder="Website/Portfolio" value={formData.website} onChange={handleChange} />
          <textarea name="about" placeholder="About Me" value={formData.about} onChange={handleChange} required />
          <textarea name="skills" placeholder="Skills (comma separated)" value={formData.skills} onChange={handleChange} required />

          <h3>Work Experience</h3>
          {formData.experience.map((exp, i) => (
            <div key={i}>
              <input placeholder="Job Title" value={exp.jobTitle} onChange={(e) => handleExperienceChange(i, "jobTitle", e.target.value)} required />
              <input placeholder="Company Name" value={exp.company} onChange={(e) => handleExperienceChange(i, "company", e.target.value)} required />
              <input placeholder="Company Location" value={exp.location} onChange={(e) => handleExperienceChange(i, "location", e.target.value)} required />
              <input type="date" value={exp.from} onChange={(e) => handleExperienceChange(i, "from", e.target.value)} required />
              <input type="date" value={exp.to} onChange={(e) => handleExperienceChange(i, "to", e.target.value)} required />
            </div>
          ))}
          <button onClick={addExperience}>Add Experience</button>

          <h3>Education</h3>
          {formData.education.map((edu, i) => (
            <div key={i}>
              <input placeholder="Diploma" value={edu.diploma} onChange={(e) => handleEducationChange(i, "diploma", e.target.value)} required />
              <input placeholder="University/College Name" value={edu.university} onChange={(e) => handleEducationChange(i, "university", e.target.value)} required />
              <input placeholder="School Location" value={edu.location} onChange={(e) => handleEducationChange(i, "location", e.target.value)} required />
              <label>
                From <input type="date" value={edu.from} onChange={(e) => handleEducationChange(i, "from", e.target.value)} required />
              </label>
              <label>
                To <input type="date" value={edu.to} onChange={(e) => handleEducationChange(i, "to", e.target.value)} required />
              </label>
            </div>
          ))}
          <button onClick={addEducation}>Add Education</button>

          <h3>Certifications</h3>
          <textarea name="certification" placeholder="Certifications (comma separated)" value={formData.certification} onChange={handleChange} />
          <h3>Projects</h3>
          <textarea name="projects" placeholder="Projects (comma separated)" value={formData.projects} onChange={handleChange} />
          <h3>Languages</h3>
          <textarea name="language" placeholder="Languages (comma separated)" value={formData.language} onChange={handleChange} />
          <h3>References</h3>
          <textarea name="references" placeholder="References (comma separated)" value={formData.references} onChange={handleChange} />

          <button onClick={handleSubmit}>Submit Your CV</button>
        </div>
      ) : (
        <div className="cv-preview">
          <h1>{formData.name}</h1>
          <p>{formData.city} | {formData.phone} | {formData.email} | {formData.linkedin} | {formData.website}</p>
          <h3>About Me</h3>
          <p>{formData.about}</p>

          <h3>Skills</h3>
          <ul>
            {formData.skills.split(",").map((skill, i) => (
              <li key={i}>{skill.trim()}</li>
            ))}
          </ul>

          <h3>Work Experience</h3>
          {formData.experience.map((exp, i) => (
            <div key={i}>
              <strong>{exp.jobTitle}</strong>
              <p>{exp.company} - {exp.location}</p>
              <p>{exp.from} - {exp.to}</p>
            </div>
          ))}

          <h3>Education</h3>
          {formData.education.map((edu, i) => (
            <div key={i}>
              <strong>{edu.diploma}</strong>
              <p>{edu.university} - {edu.location}</p>
              <p>{edu.from} - {edu.to}</p>
            </div>
          ))}

          <h3>Certifications</h3>
          <p>{formData.certification}</p>

          <h3>Projects</h3>
          <p>{formData.projects}</p>

          <h3>Languages</h3>
          <p>{formData.language}</p>

          <h3>References</h3>
          <p>{formData.references}</p>

          <div className="cv-buttons">
            <button onClick={handleEdit}>Edit</button>
            <button onClick={downloadPDF}>Download Your CV</button>
          </div>
        </div>
      )}
    </div>
  );
}
